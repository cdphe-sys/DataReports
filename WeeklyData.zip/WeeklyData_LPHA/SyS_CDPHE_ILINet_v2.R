##SyS CDPHE ILInet##

## Load Packages ##
library(lubridate)
library(httr)
library(janitor) 
library(DT)
library(jsonlite)
library(broom)
library(Rnssp)
library(tidyverse)
library(tidytext)
library(tidyr)
library(plyr)
library(dplyr)
library(widyr)
library(MMWRweek)
library(xlsx)
library(writexl)

setwd("~/WeeklyData")

## Set NSSP user profile ----
myProfile <- readRDS("myProfile.rds")

# API DATA #
#set dates for one week (the most recent complete MMWR week, Sunday-Saturday)

startdate <- "27Jul2025"
enddate <- "2Aug2025"
date <- "TEST"
week <- "31"
year <- "2025"

#set facilties (ILI facilities list)

facilities <- "1345&geography=1337&geography=1338&geography=1340&geography=31461&geography=1327&geography=1333&geography=1339&geography=1332&geography=32052&geography=1336&geography=1325&geography=31463&geography=1329&geography=1335&geography=1334&geography=1324&geography=1328&geography=24996&geography=24994&geography=24995&geography=1330&geography=1343&geography=1344&geography=31464&geography=1342&geography=1326&geography=1331&geography=1352&geography=1348&geography=16434&geography=1353&geography=1346&geography=1349&geography=1350&geography=32424&geography=32425&geography=31455&geography=31456&geography=31462&geography=31358&geography=31410&geography=31457&geography=31458&geography=31459&geography=1341&geography=31460&geography=33434&geography=33223&geography=33234&geography=33232&geography=33304&geography=33296&geography=33298&geography=33299&geography=33302&geography=32422&geography=33301&geography=32051&geography=32309&geography=32311&geography=32423&geography=33303"

##ILI Age Groups x Facility, Facility Number, Zip Code, and County

url_ili <- paste0("https://essence.syndromicsurveillance.org/nssp_essence/api/tableBuilder/csv?percentParam=noPercent&patientClass=e&medicalGroupingSystem=essencesyndromes&userId=583&geographySystem=hospital&ccddCategory=ili%20ccdd%20v1&geography=",facilities,"&datasource=va_hosp&timeResolution=weekly&aqtTarget=TableBuilder&detector=nodetectordetector&fieldIDs=timeResolution&fieldIDs=geographyhospital&fieldIDs=ageCDCILI&fieldLabels=Week&fieldLabels=Hospital&fieldLabels=CDC%20ILI%20Reporting%20Age%20Group&displayTotals=false&displayTotals=false&displayTotals=false&displayZeroCountRows=true&graphWidth=499&portletId=197984&dateconfig=15&startDate=",startdate, "&endDate=",enddate, "&rowFields=timeResolution&rowFields=geographyhospital&columnField=ageCDCILI")

ili_net <- myProfile$get_api_data(url_ili, fromCSV = TRUE) %>%
  dplyr::select(timeResolution,
         geographyhospital,
         "ILI 00-04" = "00-04",
         "ILI 05-24" = "05-24",
         "ILI 25-49" = "25-49",
         "ILI 50-64" = "50-64",
         "ILI 65+" = "65+")

##All ED Visits x Facility, Facility Number, Zip Code, and County

url_alled <- paste0("https://essence.syndromicsurveillance.org/nssp_essence/api/tableBuilder/csv?geographySystem=hospital&percentParam=noPercent&patientClass=e&geography=",facilities,"&datasource=va_hosp&medicalGroupingSystem=essencesyndromes&timeResolution=weekly&aqtTarget=TableBuilder&userId=583&detector=nodetectordetector&fieldIDs=timeResolution&fieldIDs=geographyhospital&fieldIDs=ageCDCILI&fieldLabels=Week&fieldLabels=Hospital&fieldLabels=CDC%20ILI%20Reporting%20Age%20Group&displayTotals=false&displayTotals=false&displayTotals=false&displayZeroCountRows=true&graphWidth=499&portletId=197985&dateconfig=15&startDate=",startdate, "&endDate=",enddate, "&rowFields=timeResolution&rowFields=geographyhospital&columnField=ageCDCILI")


totalED <- myProfile$get_api_data(url_alled, fromCSV = TRUE) %>%
  dplyr::select(timeResolution,
         geographyhospital,
         "All ED 00-04" = "00-04",
         "All ED 05-24" = "05-24",
         "All ED 25-49" = "25-49",
         "All ED 50-64" = "50-64",
         "All ED 65+" = "65+",
         "All ED Unknown" = "Unknown")


totalED$`All ED 00-04` <- as.numeric(totalED$`All ED 00-04`)
totalED$`All ED 05-24` <- as.numeric(totalED$`All ED 05-24`)
totalED$`All ED 25-49` <- as.numeric(totalED$`All ED 25-49`)
totalED$`All ED 50-64` <- as.numeric(totalED$`All ED 50-64`)
totalED$`All ED 65+` <- as.numeric(totalED$`All ED 65+`)
totalED$`All ED Unknown` <- as.numeric(totalED$`All ED Unknown`)

totalED$'ALL ED PatientTotal' = (totalED$`All ED 00-04` +
                                   totalED$`All ED 05-24` +
                                   totalED$`All ED 25-49` +
                                   totalED$`All ED 50-64` +
                                   totalED$`All ED 65+` +
                                   totalED$`All ED Unknown`)


# COMBINE ALL DATA #

static <- read_csv("ILInet_DataTable_revised20240206.csv")
static$`CDC Facility Number` <- as.character(static$`CDC Facility Number`)
static$zipcode <- as.character(static$zipcode)
static <- static %>%
  mutate(geographyhospital = gsub("CO_NCR", "CO", geographyhospital))


ILI <- merge(ili_net, totalED, by=c("timeResolution","geographyhospital"))
ILI <- merge(ILI, static, by="geographyhospital")
ILI <- ILI %>% 
  mutate(timeResolution = gsub("20", "", timeResolution)) %>%
  mutate(timeResolution = gsub("-", "", timeResolution))
ILI <- ILI %>%
  dplyr::rename("MMWR" = "timeResolution")
names(ILI$geographyhospital) <- NULL
ILI <- ILI[,c(2,1,15,16,17,3,4,5,6,7,8,9,10,11,12,13,14)]
ILI <- ILI %>%
  add_row(summarise_all(., ~if(is.numeric(.)) sum(.) else ""))


##SAVE AS XLSX

filename <- paste0(year, "_", date, "_", year, "WK", week, "CDC.xlsx")
filepath <- paste0("Output/",filename)

write_xlsx(ILI, 
           path = filepath, 
           col_names = T)

rm(list = ls())
